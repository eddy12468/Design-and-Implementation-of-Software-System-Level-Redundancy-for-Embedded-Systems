#!/bin/bash

cp -a /mnt/gluster1/* /dmtcp
sudo chmod 777 /dmtcp/*
