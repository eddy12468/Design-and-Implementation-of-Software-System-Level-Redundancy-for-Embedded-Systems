#!/bin/bash

cp -a /dmtcp/* /mnt/gluster1/
#sudo chmod 777 /dmtcp/*
